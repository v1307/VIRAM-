package com.lti.shopping.DAOImpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.shopping.DAO.ProductDAO;
import com.lti.shopping.model.Product;

@Repository("ProductDAO")
public class ProductDAOImpl implements ProductDAO {

	private static final Logger logger = LoggerFactory.getLogger(ProductDAOImpl.class);

	Transaction tx;
	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@Override
	public Product get(Integer product_id) {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Product p = (Product) session.get(Product.class, product_id);
		logger.info("Product loaded successfully, Product details=" + p);
		return p;
	}

	@Override
	public void add(Product product) {
		Session session = this.sessionFactory.openSession();
		tx = session.beginTransaction();
		session.save(product);
		tx.commit();
		session.close();
		logger.info("Product details saved successfully, User Details=" + product);
	}

	@Override
	public void updProduct(Product product) {
		Session session = this.sessionFactory.openSession();
		tx = session.beginTransaction();
		session.saveOrUpdate(product);
		logger.info("Person updated successfully,Person Details=" + product);
		tx.commit();
		session.close();
	}

	@Override
	public void delProduct(int product_id) {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Product product = (Product) session.get(Product.class, product_id);
		session.delete(product);
		tx.commit();
		session.close();
	}

	@Override
	public List<Product> listProducts() {
		Session session = this.sessionFactory.openSession();
		tx = session.beginTransaction();
		List<Product> productList = session.createQuery("from Product").list();
		for (Product p : productList) {
			logger.info("Product List::" + p);
		}
		session.close();
		return productList;
	}
}
