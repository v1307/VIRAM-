package com.lti.shopping.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.shopping.model.Product;

@Service
public interface ProductService {

	public Product get(Integer product_id);

	public List<Product> listProducts();

	void add(Product product);

	void update(Product product);

	void delete(int product_id);

}
