package com.lti.shopping.service;

import org.springframework.stereotype.Service;

import com.lti.shopping.model.UserDetails;

@Service
public interface UserService {

	public void addUser(UserDetails u);

	boolean verifyUser(String username, String password);

	public String getByEmail(String email);

}
