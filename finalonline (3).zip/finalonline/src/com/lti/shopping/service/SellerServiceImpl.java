package com.lti.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.shopping.DAO.SellerDAO;
import com.lti.shopping.model.Seller;

@Service
@Transactional
public class SellerServiceImpl implements SellerService {

	@Autowired
	private SellerDAO sellerDAO;

	public SellerDAO getSellerDAO() {
		return sellerDAO;
	}

	public void setSellerDAO(SellerDAO sellerDAO) {
		this.sellerDAO = sellerDAO;
	}

	@Override
	@Transactional
	public boolean verifySeller(String email, String password) {

		return sellerDAO.verifySeller(email, password);
	}

	@Override
	@Transactional
	public void addSeller(Seller s) {
		this.sellerDAO.addSeller(s);

	}

	@Override
	@Transactional
	public List<Seller> listSellers() {

		return sellerDAO.listSellers();

	}

	@Override
	@Transactional
	public void removeSeller(int sellId) {
		this.sellerDAO.removeSeller(sellId);

	}

	@Override
	public Seller getByEmail(String email) {
		return sellerDAO.getByEmail(email);
	}

}
