
package com.lti.shopping.model;

import java.io.Serializable;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "Seller")
public class Seller implements Serializable {

	private static final long serialVersionUID = 1L;

	//Mapping
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "seller",fetch=FetchType.EAGER)
	private List<Product> plist;

	
	//Instance variable
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer sellId;

	private String firstName;

	private String lastName;

	private String email;

	private String address;

	private String password;

	private String confirmPassword;

	@Column(name = "contactno")
	private int contactNumber;
	
	
	//constructor
	public Seller() {
		super();
	}
	
	
	//Setters and Getters

	public Integer getSellId() {
		return sellId;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public void setSellId(Integer sellId) {
		this.sellId = sellId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(int contactNumber) {
		this.contactNumber = contactNumber;
	}

	
	public List<Product> getPlist() {
		return plist;
	}

	public void setPlist(List<Product> plist) {
		this.plist = plist;
		
	}


	@Override
	public String toString() {
		return "Seller [plist=" + plist + ", sellId=" + sellId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", email=" + email + ", address=" + address + ", password=" + password + ", confirmPassword="
				+ confirmPassword + ", contactNumber=" + contactNumber + "]";
	}

	
	
}
