package com.lti.shopping.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "OrderDetail")
public class OrderDetail {

	
	//Instance Variable
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int orderid;
	private String productName;
	private String pdescription;
	private int quantity;
	private int price;
	 
	
public OrderDetail() {
		super();
	}

	//setters and getters
	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getPdescription() {
		return pdescription;
	}

	public void setPdescription(String pdescription) {
		this.pdescription = pdescription;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	public int getGrandTotal() {
		return (price * quantity);
	}

	@Override
	public String toString() {
		return "Order [productName=" + productName + ", pdescription=" + pdescription + ", quantity=" + quantity
				+ ", price=" + price + "]";
	}
}
